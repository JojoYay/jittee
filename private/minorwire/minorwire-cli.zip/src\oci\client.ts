import * as common from 'oci-common'
import * as identity from 'oci-identity'
import * as core from 'oci-core'
import { readFileSync } from 'node:fs'
import type { OciCredentials } from './provisionPlan.js'

export type OciClients = {
  provider: common.SimpleAuthenticationDetailsProvider
  identity: identity.IdentityClient
  compute: core.ComputeClient
  network: core.VirtualNetworkClient
}

export function requireCreds(creds: OciCredentials): asserts creds is OciCredentials & {
  fingerprint: string
  privateKeyPath: string
} {
  const missing: string[] = []
  if (!creds.tenancyOcid || creds.tenancyOcid.startsWith('(')) missing.push('MINORWIRE_TENANCY_OCID')
  if (!creds.userOcid || creds.userOcid.startsWith('(')) missing.push('MINORWIRE_USER_OCID')
  if (!creds.compartmentOcid || creds.compartmentOcid.startsWith('(')) missing.push('MINORWIRE_COMPARTMENT_OCID')
  if (!creds.fingerprint) missing.push('MINORWIRE_FINGERPRINT')
  if (!creds.privateKeyPath) missing.push('MINORWIRE_PRIVATE_KEY_PATH')
  if (missing.length) {
    throw new Error(`Missing required env: ${missing.join(', ')}`)
  }
}

export function createClients(creds: OciCredentials): OciClients {
  requireCreds(creds)
  const privateKey = readFileSync(creds.privateKeyPath, 'utf8')
  const region = common.Region.fromRegionId(creds.region)
  const provider = new common.SimpleAuthenticationDetailsProvider(
    creds.tenancyOcid,
    creds.userOcid,
    creds.fingerprint,
    privateKey,
    null,
    region,
  )
  return {
    provider,
    identity: new identity.IdentityClient({ authenticationDetailsProvider: provider }),
    compute: new core.ComputeClient({ authenticationDetailsProvider: provider }),
    network: new core.VirtualNetworkClient({ authenticationDetailsProvider: provider }),
  }
}
