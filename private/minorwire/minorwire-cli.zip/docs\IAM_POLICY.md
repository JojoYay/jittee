# Least-privilege IAM for MinorWire

Customers create a dedicated IAM **group**, **user**, and **API key**.  
Do not share the tenancy administrator account.

## Console checklist

1. Identity → Domains → Default → **Groups** → Create group `MinorWire`
2. Identity → **Policies** → Create policy `minorwire-provision` (paste below; set compartment name)
3. Identity → **Users** → Create user → Add to group `MinorWire`
4. User → API keys → Add API key → download the private key (PEM)
5. Copy: User OCID, Tenancy OCID, target Compartment OCID, Region

## App inputs

| Field | Example |
|-------|---------|
| Region | `ap-tokyo-1` |
| Tenancy OCID | `ocid1.tenancy.oc1.....` |
| Compartment OCID | `ocid1.compartment.oc1.....` |
| User OCID | `ocid1.user.oc1.....` |
| API key (PEM) | private key file contents |

## Copy-ready policy

Replace `TARGET_COMPARTMENT` with the **compartment name** (not OCID) where MinorWire may create resources. Root compartment name is usually the tenancy name.

```text
Allow group MinorWire to manage instance-family in compartment TARGET_COMPARTMENT
Allow group MinorWire to manage volume-family in compartment TARGET_COMPARTMENT
Allow group MinorWire to manage virtual-network-family in compartment TARGET_COMPARTMENT
Allow group MinorWire to use vnics in compartment TARGET_COMPARTMENT
Allow group MinorWire to use subnets in compartment TARGET_COMPARTMENT
Allow group MinorWire to read app-catalog-listing in tenancy
Allow group MinorWire to inspect compartments in tenancy
Allow group MinorWire to read instance-images in tenancy
```

### What this allows

- Create / manage Always Free Micro instances and boot volumes
- Create VCN, public subnet, Internet Gateway, route tables, security lists / NSGs
- Attach VNICS and use subnets
- Read platform images and compartment metadata

### What this does not allow

- Other compartments (unless you widen the policy)
- IAM / policy / user admin
- Billing
- Databases, Object Storage admin, OKE, etc.

## Notes

- Prefer a **dedicated compartment** (e.g. `minorwire`) so blast radius stays small.
- Prefer **Internet Gateway + public subnet** for the VPN VM; avoid NAT Gateway on Always Free (often unavailable or billable).
- After setup, customers can remove the API key; peer management can use SSH only if desired.
