export type OciCredentials = {
  region: string
  tenancyOcid: string
  compartmentOcid: string
  userOcid: string
  fingerprint?: string
  privateKeyPath?: string
}

export type ProvisionPlanStep = {
  id: string
  title: string
  detail: string
}

/** Ordered work the provisioner will perform (OCI API + SSH bootstrap). */
export function buildProvisionPlan(creds: Pick<OciCredentials, 'region' | 'compartmentOcid'>): ProvisionPlanStep[] {
  return [
    {
      id: 'validate-creds',
      title: 'Validate OCI credentials',
      detail: `Call Identity GetUser / list availability domains in ${creds.region}`,
    },
    {
      id: 'ensure-vcn',
      title: 'Ensure network',
      detail:
        'Create or reuse a VCN with public subnet + Internet Gateway + security rules (SSH/22, UDP/51820). Avoid NAT Gateway.',
    },
    {
      id: 'launch-instance',
      title: 'Launch Always Free Micro',
      detail: `Launch VM.Standard.E2.1.Micro (Ubuntu LTS) in compartment ${creds.compartmentOcid} with ephemeral public IP`,
    },
    {
      id: 'wait-ssh',
      title: 'Wait for SSH',
      detail: 'Poll until ubuntu@<public-ip> accepts the provision SSH key',
    },
    {
      id: 'bootstrap-wireguard',
      title: 'Bootstrap WireGuard',
      detail: 'Upload and run scripts/wg-setup.sh; confirm `wg show` listens on 51820',
    },
    {
      id: 'ready',
      title: 'Ready for peers',
      detail: 'App can call wg-add-peer (or equivalent) to mint device configs / QR codes',
    },
  ]
}
