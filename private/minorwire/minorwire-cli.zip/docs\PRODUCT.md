# MinorWire — Product brief (MVP)

## What we sell

A setup + management tool that provisions WireGuard on the **customer's** Oracle Cloud Always Free tenancy, then issues device configs (Windows / Android / iOS / macOS) from a small app.

We do **not** sell VPN bandwidth. Traffic runs on the customer's OCI instance.

## Stripe SKUs (one-time)

| SKU | Price | Includes |
|-----|-------|----------|
| `minorwire_app` | SGD 10 | App license + self-serve guide (IAM policy snippet, OCID checklist, provision flow) |
| `minorwire_setup` | SGD 100 | App + live assisted setup (screen share through IAM key creation, first VPN up, first device config) |

Currency: **SGD** (Stripe Prices in `sgd`). Suggested upsell: buy app (S$10), then upgrade to assisted for +S$90.

No monthly VPN fee in MVP. Optional later: support subscription.

## Customer inputs (app first-run)

- Region (e.g. `ap-tokyo-1`)
- Tenancy OCID
- Compartment OCID
- User OCID (dedicated least-privilege user)
- API key private key (PEM)

## Provisioned resources (target)

- Always Free shape: `VM.Standard.E2.1.Micro` when available
- Ubuntu LTS image
- VCN with public subnet + Internet Gateway (avoid paid NAT if possible)
- Security List / NSG: SSH + UDP 51820
- WireGuard (`wg0`) + peer-add helper used by the app

## Flows

### Self-serve (S$10)

1. Pay Stripe → download app / unlock license
2. Customer creates IAM user + policy (copy-paste from in-app guide)
3. Paste OCI credentials into app
4. App runs provision + health check
5. App creates peers / QR / `.conf` per device

### Assisted (S$100)

Same outcome; Jittee walks steps 2–5 in one session (time-box in offer, e.g. 60 minutes, 2 devices).

## Client strategy (MVP)

**Approach A — config issuer only.**  
MinorWire creates peers and hands the user a QR code or `.conf` file. Connection uses the official WireGuard apps (Windows / Android / iOS / macOS). No embedded tunnel in MVP.

**Current deliverable form (honest):**  
Not a Windows GUI installer yet. Sales happen on jittee.com `/minorwire` via Stripe PayNow. The product body is the **Node.js CLI** (`validate` / `provision` / `bootstrap` / `peer`) plus IAM guide. After payment, fulfillment is email of the CLI package (auto-download later). GUI desktop app is a later phase.

Wrapped native VPN apps (Approach B) are a later phase if needed.

## Non-goals (MVP)

- Hosting VPN on Jittee infrastructure
- Multi-tenant SaaS control plane beyond license check
- Guaranteeing Always Free capacity in every region
- Shipping a branded tunnel app on day one (QR / file import into official WireGuard)

## Compliance notes

- Least-privilege IAM only; never ask for full tenancy admin if avoidable
- Clear ToS: quality depends on customer's Always Free limits; stop/start from OCI console can change ephemeral public IP
- Customer owns the OCI bill and Free Tier eligibility

## Related

- Marketing: jittee.com `/minorwire`
- Reference bootstrap: `scripts/wg-setup.sh`
- CLI (Approach A): `validate` → `provision` → `bootstrap` → `peer <name>` writes a `.conf` for official WireGuard apps
