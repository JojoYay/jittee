import { Client, type ConnectConfig } from 'ssh2'
import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'

function connect(cfg: ConnectConfig): Promise<Client> {
  return new Promise((resolvePromise, reject) => {
    const client = new Client()
    client
      .on('ready', () => resolvePromise(client))
      .on('error', reject)
      .connect(cfg)
  })
}

function exec(client: Client, command: string): Promise<{ code: number; stdout: string; stderr: string }> {
  return new Promise((resolvePromise, reject) => {
    client.exec(command, (err, stream) => {
      if (err) return reject(err)
      let stdout = ''
      let stderr = ''
      stream
        .on('close', (code: number) => resolvePromise({ code: code ?? 0, stdout, stderr }))
        .on('data', (d: Buffer) => {
          stdout += d.toString('utf8')
        })
      stream.stderr.on('data', (d: Buffer) => {
        stderr += d.toString('utf8')
      })
    })
  })
}

function upload(client: Client, localPath: string, remotePath: string): Promise<void> {
  return new Promise((resolvePromise, reject) => {
    client.sftp((err, sftp) => {
      if (err) return reject(err)
      sftp.fastPut(localPath, remotePath, (e) => (e ? reject(e) : resolvePromise()))
    })
  })
}

function download(client: Client, remotePath: string, localPath: string): Promise<void> {
  return new Promise((resolvePromise, reject) => {
    client.sftp((err, sftp) => {
      if (err) return reject(err)
      sftp.fastGet(remotePath, localPath, (e) => (e ? reject(e) : resolvePromise()))
    })
  })
}

async function withRetryConnect(cfg: ConnectConfig, attempts = 30): Promise<Client> {
  let last: unknown
  for (let i = 0; i < attempts; i++) {
    try {
      return await connect(cfg)
    } catch (e) {
      last = e
      await new Promise((r) => setTimeout(r, 10_000))
    }
  }
  throw last instanceof Error ? last : new Error(String(last))
}

export async function bootstrapWireGuard(opts: {
  host: string
  privateKeyPath: string
  scriptPath?: string
}): Promise<void> {
  const scriptPath = resolve(opts.scriptPath ?? 'scripts/wg-setup.sh')
  const privateKey = readFileSync(opts.privateKeyPath)
  const client = await withRetryConnect({
    host: opts.host,
    port: 22,
    username: 'ubuntu',
    privateKey,
    readyTimeout: 30_000,
  })
  try {
    console.log(`==> Uploading ${scriptPath}`)
    await upload(client, scriptPath, '/home/ubuntu/wg-setup.sh')
    const run = await exec(
      client,
      'sed -i "s/\\r$//" /home/ubuntu/wg-setup.sh && sudo bash /home/ubuntu/wg-setup.sh && sudo wg show',
    )
    process.stdout.write(run.stdout)
    if (run.stderr) process.stderr.write(run.stderr)
    if (run.code !== 0) {
      throw new Error(`wg-setup.sh failed with exit ${run.code}`)
    }
  } finally {
    client.end()
  }
}

export async function addPeerAndFetchConfig(opts: {
  host: string
  privateKeyPath: string
  peerName: string
  outPath: string
}): Promise<string> {
  if (!/^[A-Za-z0-9_-]+$/.test(opts.peerName)) {
    throw new Error('peer name must be alphanumeric / - / _')
  }
  const privateKey = readFileSync(opts.privateKeyPath)
  const client = await connect({
    host: opts.host,
    port: 22,
    username: 'ubuntu',
    privateKey,
  })
  try {
    const add = await exec(client, `sudo wg-add-peer ${opts.peerName}`)
    process.stdout.write(add.stdout)
    if (add.code !== 0) {
      process.stderr.write(add.stderr)
      throw new Error(`wg-add-peer failed with exit ${add.code}`)
    }
    await exec(
      client,
      `sudo cp /etc/wireguard/clients/${opts.peerName}.conf /home/ubuntu/${opts.peerName}.conf && sudo chown ubuntu:ubuntu /home/ubuntu/${opts.peerName}.conf`,
    )
    const outPath = resolve(opts.outPath)
    await download(client, `/home/ubuntu/${opts.peerName}.conf`, outPath)
    return outPath
  } finally {
    client.end()
  }
}
