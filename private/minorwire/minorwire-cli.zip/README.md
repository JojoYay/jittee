# MinorWire

Provision WireGuard on the customer's Oracle Cloud Always Free tenancy, then issue device configs for the official WireGuard apps (Windows / Android / iOS / macOS).

Marketing page (Jittee site): `/minorwire`

## Pricing (MVP, one-time via Stripe)

| SKU | Price | Includes |
|-----|-------|----------|
| `minorwire_app` | SGD 10 | App + self-serve IAM guide + provision flow |
| `minorwire_setup` | SGD 100 | App + live assisted setup |

No monthly VPN bandwidth fee — traffic stays on the customer's OCI instance.

## Setup

```bash
npm install
cp .env.example .env
# Fill OCI tenancy / user / compartment OCIDs, API key fingerprint, and private key path
```

Create the IAM group + policy first (`npm run policy`), then create a least-privilege user with an API key in that group. See `docs/IAM_POLICY.md`.

## CLI

```bash
npm run policy          # copy-ready IAM statements
npm run plan            # print provision steps
npm run validate        # verify API credentials against OCI
npm run provision       # create VCN + Always Free Micro + public IP
npm run bootstrap       # SSH in and run scripts/wg-setup.sh
npm run peer -- android # mint a .conf for the official WireGuard app
```

State is written to `.minorwire/state.json` (gitignored). Peer configs are written as `*.conf` in the working directory unless `--out` is set.

## Repo layout

```
docs/          Product and IAM notes
scripts/       Server bootstrap (WireGuard) used after instance create
src/           TypeScript CLI (OCI provision + SSH bootstrap + peer)
app/           Desktop client (to be built)
```

## Status

- IAM policy text: ready
- WireGuard bootstrap script: ready
- OCI validate / provision / bootstrap / peer: CLI implemented
- Next: Windows app shell, Stripe SKUs on jittee `/minorwire`
