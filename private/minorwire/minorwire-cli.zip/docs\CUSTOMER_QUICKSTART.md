# MinorWire CLI — Quick start

## Requirements

- Node.js 20+
- Oracle Cloud Always Free eligibility and spare Micro capacity
- A least-privilege IAM user + API key (see `docs/IAM_POLICY.md`)

## Setup

```bash
npm install
cp .env.example .env
# Fill OCIDs, fingerprint, and private key path in .env
```

## Commands

```bash
npm run policy          # print IAM policy text
npm run validate        # check OCI credentials
npm run provision       # create VCN + Always Free Micro + public IP
npm run bootstrap       # install WireGuard on the instance
npm run peer -- android # download android.conf for official WireGuard
```

State is saved under `.minorwire/state.json` (do not commit).

## Device connection

Import the generated `.conf` (or QR) into the **official WireGuard app** on Windows / Android / iOS / macOS.

## Assisted setup (S$100)

If you bought assisted setup, email **info@jittee.com** with your checkout email to schedule a screen-share session.
