import { readFileSync, existsSync } from 'node:fs'
import { resolve } from 'node:path'
import { buildIamPolicy } from './iam/policyText.js'
import { buildProvisionPlan, type OciCredentials } from './oci/provisionPlan.js'
import { validateCredentials } from './oci/validate.js'
import { provisionAlwaysFreeVpn } from './oci/provision.js'
import { bootstrapWireGuard, addPeerAndFetchConfig } from './ssh/remote.js'

function loadDotEnv(path = '.env'): void {
  if (!existsSync(path)) return
  for (const line of readFileSync(path, 'utf8').split(/\r?\n/)) {
    const trimmed = line.trim()
    if (!trimmed || trimmed.startsWith('#')) continue
    const i = trimmed.indexOf('=')
    if (i <= 0) continue
    const key = trimmed.slice(0, i).trim()
    const value = trimmed.slice(i + 1).trim()
    if (!(key in process.env)) process.env[key] = value
  }
}

function printHelp(): void {
  console.log(`MinorWire CLI

Usage:
  npx tsx src/cli.ts policy [compartment-name]
  npx tsx src/cli.ts plan
  npx tsx src/cli.ts validate
  npx tsx src/cli.ts provision [--name displayName]
  npx tsx src/cli.ts bootstrap [--host ip] [--key path]
  npx tsx src/cli.ts peer <name> [--host ip] [--key path] [--out file]
  npx tsx src/cli.ts version

Commands:
  policy     Print copy-ready IAM policy statements
  plan       Print provision steps
  validate   Call OCI Identity APIs with env credentials
  provision  Create VCN + Always Free Micro + public IP (writes .minorwire/state.json)
  bootstrap  Upload scripts/wg-setup.sh over SSH and run it
  peer       Add a WireGuard peer and download .conf for official WireGuard apps
`)
}

function loadCredsFromEnv(): OciCredentials {
  return {
    region: process.env.MINORWIRE_REGION ?? 'ap-tokyo-1',
    tenancyOcid: process.env.MINORWIRE_TENANCY_OCID ?? '(set MINORWIRE_TENANCY_OCID)',
    compartmentOcid: process.env.MINORWIRE_COMPARTMENT_OCID ?? '(set MINORWIRE_COMPARTMENT_OCID)',
    userOcid: process.env.MINORWIRE_USER_OCID ?? '(set MINORWIRE_USER_OCID)',
    fingerprint: process.env.MINORWIRE_FINGERPRINT,
    privateKeyPath: process.env.MINORWIRE_PRIVATE_KEY_PATH,
  }
}

function readState(): {
  publicIp: string
  sshPrivateKeyPath: string
} {
  const p = resolve('.minorwire/state.json')
  if (!existsSync(p)) {
    throw new Error('Missing .minorwire/state.json — run provision first, or pass --host/--key')
  }
  return JSON.parse(readFileSync(p, 'utf8')) as { publicIp: string; sshPrivateKeyPath: string }
}

function flagValue(args: string[], name: string): string | undefined {
  const i = args.indexOf(name)
  if (i >= 0 && args[i + 1]) return args[i + 1]
  return undefined
}

function cmdPolicy(compartmentName: string): void {
  console.log(buildIamPolicy(compartmentName))
  console.log('')
  console.log('# Create IAM group "MinorWire", attach this policy, then create a user + API key in that group.')
}

function cmdPlan(): void {
  const creds = loadCredsFromEnv()
  const steps = buildProvisionPlan(creds)
  console.log(`Provision plan (${creds.region})`)
  console.log(`Compartment: ${creds.compartmentOcid}`)
  console.log('')
  for (const [i, step] of steps.entries()) {
    console.log(`${i + 1}. [${step.id}] ${step.title}`)
    console.log(`   ${step.detail}`)
  }
}

async function cmdValidate(): Promise<void> {
  const result = await validateCredentials(loadCredsFromEnv())
  console.log('OK')
  console.log(`User: ${result.userName} (${result.userOcid})`)
  console.log(`Region: ${result.region}`)
  console.log(`ADs: ${result.availabilityDomains.join(', ')}`)
}

async function cmdProvision(args: string[]): Promise<void> {
  const name = flagValue(args, '--name')
  const result = await provisionAlwaysFreeVpn(loadCredsFromEnv(), { displayName: name })
  console.log('')
  console.log('Provision complete')
  console.log(`Instance: ${result.displayName} (${result.instanceId})`)
  console.log(`Public IP: ${result.publicIp}`)
  console.log(`SSH key: ${result.sshPrivateKeyPath}`)
  console.log('')
  console.log('Next: npx tsx src/cli.ts bootstrap')
}

async function cmdBootstrap(args: string[]): Promise<void> {
  const state = existsSync(resolve('.minorwire/state.json')) ? readState() : undefined
  const host = flagValue(args, '--host') ?? state?.publicIp
  const key = flagValue(args, '--key') ?? state?.sshPrivateKeyPath
  if (!host || !key) throw new Error('Need --host and --key (or .minorwire/state.json)')
  await bootstrapWireGuard({ host, privateKeyPath: key })
  console.log('')
  console.log('WireGuard is up. Add a device config with:')
  console.log('  npx tsx src/cli.ts peer android')
}

async function cmdPeer(args: string[]): Promise<void> {
  const peerName = args.find((a) => !a.startsWith('--') && a !== 'peer')
  if (!peerName) throw new Error('usage: peer <name>')
  const state = existsSync(resolve('.minorwire/state.json')) ? readState() : undefined
  const host = flagValue(args, '--host') ?? state?.publicIp
  const key = flagValue(args, '--key') ?? state?.sshPrivateKeyPath
  const out = flagValue(args, '--out') ?? resolve(`${peerName}.conf`)
  if (!host || !key) throw new Error('Need --host and --key (or .minorwire/state.json)')
  const path = await addPeerAndFetchConfig({
    host,
    privateKeyPath: key,
    peerName,
    outPath: out,
  })
  console.log('')
  console.log(`Wrote ${path}`)
  console.log('Import this file (or its QR from the server output) into the official WireGuard app.')
}

function cmdVersion(): void {
  const pkgPath = resolve(process.cwd(), 'package.json')
  const pkg = JSON.parse(readFileSync(pkgPath, 'utf8')) as { version: string }
  console.log(pkg.version)
}

async function main(argv: string[]): Promise<void> {
  loadDotEnv()
  const [, , cmd, ...rest] = argv
  try {
    switch (cmd) {
      case 'policy':
        cmdPolicy(rest[0] ?? 'TARGET_COMPARTMENT')
        break
      case 'plan':
        cmdPlan()
        break
      case 'validate':
        await cmdValidate()
        break
      case 'provision':
        await cmdProvision(rest)
        break
      case 'bootstrap':
        await cmdBootstrap(rest)
        break
      case 'peer':
        await cmdPeer(rest)
        break
      case 'version':
        cmdVersion()
        break
      case 'help':
      case undefined:
        printHelp()
        break
      default:
        console.error(`Unknown command: ${cmd}`)
        printHelp()
        process.exitCode = 1
    }
  } catch (e) {
    console.error(e instanceof Error ? e.message : e)
    process.exitCode = 1
  }
}

void main(process.argv)
