import { randomBytes } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { mkdirSync, writeFileSync, readFileSync, existsSync, unlinkSync } from 'node:fs'
import { resolve } from 'node:path'
import * as core from 'oci-core'
import type { OciCredentials } from './provisionPlan.js'
import { createClients } from './client.js'
import { validateCredentials } from './validate.js'

const SHAPE = 'VM.Standard.E2.1.Micro'
const DISPLAY_PREFIX = 'minorwire'

export type ProvisionResult = {
  instanceId: string
  displayName: string
  publicIp: string
  privateIp: string
  availabilityDomain: string
  subnetId: string
  vcnId: string
  sshPrivateKeyPath: string
  region: string
}

export type ProvisionOptions = {
  displayName?: string
  stateDir?: string
}

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms))
}

function ensureSshKeyPair(stateDir: string): { publicKeyOpenSsh: string; privateKeyPath: string } {
  const keyPath = resolve(stateDir, 'ssh_instance_key')
  const pubPath = `${keyPath}.pub`
  if (existsSync(keyPath) && existsSync(pubPath)) {
    return {
      privateKeyPath: keyPath,
      publicKeyOpenSsh: readFileSync(pubPath, 'utf8').trim(),
    }
  }
  for (const p of [keyPath, pubPath, `${keyPath}.pub`]) {
    if (existsSync(p)) unlinkSync(p)
  }
  execFileSync('ssh-keygen', ['-t', 'ed25519', '-N', '', '-f', keyPath, '-C', 'minorwire-provision'], {
    stdio: 'ignore',
  })
  return {
    privateKeyPath: keyPath,
    publicKeyOpenSsh: readFileSync(pubPath, 'utf8').trim(),
  }
}

async function pickUbuntuImage(compute: core.ComputeClient, compartmentId: string): Promise<string> {
  const res = await compute.listImages({
    compartmentId,
    operatingSystem: 'Canonical Ubuntu',
    operatingSystemVersion: '24.04',
    shape: SHAPE,
    sortBy: core.requests.ListImagesRequest.SortBy.Timecreated,
    sortOrder: core.requests.ListImagesRequest.SortOrder.Desc,
    limit: 20,
  })
  const images = (res.items ?? []).filter((i) => !i.displayName?.toLowerCase().includes('aarch64'))
  const img = images[0]
  if (!img?.id) {
    throw new Error('No Ubuntu 24.04 image found for VM.Standard.E2.1.Micro in this compartment/region')
  }
  return img.id
}

async function waitInstanceRunning(compute: core.ComputeClient, instanceId: string): Promise<void> {
  for (let i = 0; i < 60; i++) {
    const { instance } = await compute.getInstance({ instanceId })
    const state = instance.lifecycleState
    if (state === 'RUNNING') return
    if (state === 'TERMINATED' || state === 'TERMINATING') {
      throw new Error(`Instance entered ${state}`)
    }
    await sleep(10_000)
  }
  throw new Error('Timed out waiting for instance RUNNING')
}

async function getPrimaryIps(
  compute: core.ComputeClient,
  network: core.VirtualNetworkClient,
  compartmentId: string,
  instanceId: string,
): Promise<{ publicIp: string; privateIp: string }> {
  for (let i = 0; i < 30; i++) {
    const attachments = await compute.listVnicAttachments({ compartmentId, instanceId })
    const primary = (attachments.items ?? []).find((a) => a.lifecycleState === 'ATTACHED' && a.vnicId)
    if (primary?.vnicId) {
      const { vnic } = await network.getVnic({ vnicId: primary.vnicId })
      if (vnic.privateIp) {
        return {
          privateIp: vnic.privateIp,
          publicIp: vnic.publicIp ?? '',
        }
      }
    }
    await sleep(5_000)
  }
  throw new Error('Could not resolve instance VNIC / IP addresses')
}

export async function provisionAlwaysFreeVpn(
  creds: OciCredentials,
  options: ProvisionOptions = {},
): Promise<ProvisionResult> {
  const stateDir = resolve(options.stateDir ?? '.minorwire')
  mkdirSync(stateDir, { recursive: true })

  const validated = await validateCredentials(creds)
  const { compute, network } = createClients(creds)
  const availabilityDomain = validated.availabilityDomains[0]
  const displayName = options.displayName ?? `${DISPLAY_PREFIX}-${randomBytes(3).toString('hex')}`
  const { publicKeyOpenSsh, privateKeyPath } = ensureSshKeyPair(stateDir)

  console.log(`==> Creating VCN stack in ${creds.region}`)
  const vcnRes = await network.createVcn({
    createVcnDetails: {
      compartmentId: creds.compartmentOcid,
      displayName: `${displayName}-vcn`,
      cidrBlocks: ['10.0.0.0/16'],
      dnsLabel: `mw${randomBytes(2).toString('hex')}`,
    },
  })
  const vcn = vcnRes.vcn
  if (!vcn.id || !vcn.defaultRouteTableId) {
    throw new Error('createVcn did not return id / defaultRouteTableId')
  }

  const igRes = await network.createInternetGateway({
    createInternetGatewayDetails: {
      compartmentId: creds.compartmentOcid,
      vcnId: vcn.id,
      displayName: `${displayName}-igw`,
      isEnabled: true,
    },
  })
  const igwId = igRes.internetGateway.id
  if (!igwId) throw new Error('createInternetGateway missing id')

  await network.updateRouteTable({
    rtId: vcn.defaultRouteTableId,
    updateRouteTableDetails: {
      routeRules: [
        {
          destination: '0.0.0.0/0',
          destinationType: core.models.RouteRule.DestinationType.CidrBlock,
          networkEntityId: igwId,
        },
      ],
    },
  })

  const slRes = await network.createSecurityList({
    createSecurityListDetails: {
      compartmentId: creds.compartmentOcid,
      vcnId: vcn.id,
      displayName: `${displayName}-sl`,
      egressSecurityRules: [
        {
          destination: '0.0.0.0/0',
          protocol: 'all',
          destinationType: core.models.EgressSecurityRule.DestinationType.CidrBlock,
        },
      ],
      ingressSecurityRules: [
        {
          source: '0.0.0.0/0',
          protocol: '6',
          sourceType: core.models.IngressSecurityRule.SourceType.CidrBlock,
          tcpOptions: { destinationPortRange: { min: 22, max: 22 } },
          description: 'SSH',
        },
        {
          source: '0.0.0.0/0',
          protocol: '17',
          sourceType: core.models.IngressSecurityRule.SourceType.CidrBlock,
          udpOptions: { destinationPortRange: { min: 51820, max: 51820 } },
          description: 'WireGuard',
        },
      ],
    },
  })
  const securityListId = slRes.securityList.id
  if (!securityListId) throw new Error('createSecurityList missing id')

  const subnetRes = await network.createSubnet({
    createSubnetDetails: {
      compartmentId: creds.compartmentOcid,
      vcnId: vcn.id,
      cidrBlock: '10.0.0.0/24',
      displayName: `${displayName}-public`,
      routeTableId: vcn.defaultRouteTableId,
      securityListIds: [securityListId],
      dnsLabel: 'public',
      prohibitPublicIpOnVnic: false,
    },
  })
  const subnetId = subnetRes.subnet.id
  if (!subnetId) throw new Error('createSubnet missing id')

  console.log(`==> Resolving Ubuntu 24.04 image for ${SHAPE}`)
  const imageId = await pickUbuntuImage(compute, creds.tenancyOcid)

  console.log(`==> Launching ${SHAPE} (${displayName})`)
  const sourceDetails: core.models.InstanceSourceViaImageDetails = {
    sourceType: 'image',
    imageId,
  }
  const launch = await compute.launchInstance({
    launchInstanceDetails: {
      availabilityDomain,
      compartmentId: creds.compartmentOcid,
      displayName,
      shape: SHAPE,
      sourceDetails,
      createVnicDetails: {
        subnetId,
        assignPublicIp: true,
        displayName: `${displayName}-vnic`,
      },
      metadata: {
        ssh_authorized_keys: publicKeyOpenSsh,
      },
    },
  })
  const instanceId = launch.instance.id
  if (!instanceId) throw new Error('launchInstance missing id')

  console.log(`==> Waiting for RUNNING (${instanceId})`)
  await waitInstanceRunning(compute, instanceId)
  const ips = await getPrimaryIps(compute, network, creds.compartmentOcid, instanceId)
  if (!ips.publicIp) {
    throw new Error('Instance has no public IP; check subnet / assignPublicIp settings')
  }

  const result: ProvisionResult = {
    instanceId,
    displayName,
    publicIp: ips.publicIp,
    privateIp: ips.privateIp,
    availabilityDomain,
    subnetId,
    vcnId: vcn.id,
    sshPrivateKeyPath: privateKeyPath,
    region: creds.region,
  }
  writeFileSync(resolve(stateDir, 'state.json'), JSON.stringify(result, null, 2))
  console.log(`==> Saved state to ${resolve(stateDir, 'state.json')}`)
  return result
}
